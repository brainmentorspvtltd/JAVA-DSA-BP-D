import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

// S O L I D
// Open Close Principle
/*
 * Saving Account
 * Current Account
 */
class Summary {
    String title;
    String desc;
    double amount;
}

class AdvanceSummary extends Summary {
    String dayWise;
    String monthWise;
}

abstract class Account {
    int id;
    String name;

    void deposit() {
        System.out.println("Account Deposit...");
    }

    // void withDraw() {
    // System.out.println("Account WithDraw...");
    // }
    abstract void withDraw();

    Summary roi() throws Exception {
        System.out.println("Account ROI...");
        Summary summary = new Summary();
        summary.title = "ROI Report";
        summary.desc = "Jan - March";
        summary.amount = 20000;
        return summary;
    }
}

class SavingAccount extends Account {
    void limit() {
        System.out.println("Saving Account Daily Limit of 50 Lakh");
    }

    @Override
    void withDraw() {
        System.out.println("saving a/c with draw with limit");
    }

    @Override
    protected AdvanceSummary roi() throws IOException {
        // super.roi();
        System.out.println("Saving Account 5% ROI");
        AdvanceSummary summary = new AdvanceSummary();
        return summary;
    }
}

class CurrentAccount extends Account {
    void odLimit() {
        System.out.println("Current Account No Limit Extra WithDraw");
    }

    @Override
    void withDraw() {
        System.out.println("CA WithDraw with od limit");
    }
}

class AccountCaller {
    void call(Account account) throws Exception {
        // Common Code
        account.deposit();
        account.withDraw();
        account.roi();

        if (account instanceof SavingAccount) {
            // downcasting
            ((SavingAccount) account).limit();

        } else if (account instanceof CurrentAccount) {
            ((CurrentAccount) account).odLimit();
        }
        System.out.println("**************************");
    }
}

public class ISA {

    static void print(List<Integer> list) {

    }

    public static void main(String[] args) throws Exception {
        print(new ArrayList<>());
        print(new LinkedList<>());
        print(new Vector<>());
        AccountCaller ac = new AccountCaller();
        // SavingAccount sa = new SavingAccount();
        // Account account = new SavingAccount(); // Upcasting
        ac.call(new SavingAccount()); // Upcasting
        ac.call(new CurrentAccount());
        // ac.call(new Account());
        // sa.deposit();
        // sa.withDraw();
        // sa.roi();
        // sa.limit();
        // System.out.println("*****************************");
        // CurrentAccount ca = new CurrentAccount();
        // ca.deposit();
        // ca.withDraw();
        // ca.roi();
        // ca.odLimit();
    }
}