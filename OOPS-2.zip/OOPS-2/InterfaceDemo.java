/*
 * Interface - Standard / Contract (What to do)
 * 100 % Abstract
 */
//interface IPlayer{
abstract interface IPlayer {
    public static final int MAX_POWER = 100;
    int MIN_POWER = 10;

    public abstract void walk();

    void jump();

    void punch();

}

interface ExtraPower {
    void power(int pow);
}

class MyPlayer {

}

// How to do
class RedPlayer extends MyPlayer implements IPlayer, ExtraPower {
    @Override
    public void walk() {
        System.out.println("Red Player Walk...");
    }

    @Override
    public void jump() {
        System.out.println("Red Player Jump");
    }

    public void punch() {
        final int VALUE = MAX_POWER;
        System.out.println("Red Player Punch " + VALUE);
    }

    @Override
    public void power(int pow) {
        System.out.println("Power " + pow);
    }
}

class WhitePlayer implements IPlayer {

    @Override
    public void walk() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'walk'");
    }

    @Override
    public void jump() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'jump'");
    }

    @Override
    public void punch() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'punch'");
    }

}

public class InterfaceDemo {
    public static void main(String[] args) {

    }
}
