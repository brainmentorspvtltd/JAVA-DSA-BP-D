package com.shop.db;

public interface IOrder {
    public void showOrder();
}
