package com.shop.db;

public class Order implements IOrder {
    public void showOrder() {
        System.out.println("Show Order");
        // summary(10, 20);
    }

    public void summary(int s, int m) {
        System.out.println("Summary ");
    }

    public void callDel() {

    }
}