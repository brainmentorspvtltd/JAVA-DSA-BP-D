class P1 {
    int x = 200;

    P1() {
        System.out.println("P1 Default Cons");
    }

    P1(int x) {
        this();
        System.out.println("P1 Param Cons " + x);
    }
}

class P2 extends P1 {
    int x = 300;

    P2() {
        super(30);
        System.out.println("P2 Default Cons");
    }

    P2(int x) {
        this();
        // super(x * x);
        System.out.println("P2 Param Cons " + x);
    }
}

class C3 extends P2 {
    int x = 100;

    C3() {
        super(20);
        // super();
        System.out.println("C3 Default Cons");
    }

    C3(int x) {
        this();
        int z = x + this.x + super.x + ((P1) this).x;
        // super(x * x);
        // super();
        System.out.println("C3 Param Cons " + x + " " + z);
    }
}

public class ConstructorChain {
    public static void main(String[] args) {
        // C3 obj = new C3();
        C3 obj = new C3(10);

    }
}
