interface M1 {
    void show();

    default void disp() {
        System.out.println("M1 Disp");
    }
}

interface M2 {
    default void disp() {
        System.out.println("M2 Disp");
    }
}

class M3 implements M1, M2 {
    @Override
    public void disp() {
        M1.super.disp();
        M2.super.disp();
        System.out.println("M3 Disp");
    }

    @Override
    public void show() {
        System.out.println("M3 Show...");
    }
}

public class ModernInterface {
    public static void main(String[] args) {
        M3 obj = new M3();
        obj.disp();
        obj.show();
    }
}
