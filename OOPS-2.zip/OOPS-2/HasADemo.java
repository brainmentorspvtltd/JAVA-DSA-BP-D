
public class HasADemo {
    public static void main(String[] args) {

    }
}
