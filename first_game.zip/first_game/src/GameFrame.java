import javax.swing.JFrame;

// Min, Max , Close 
class GameFrame extends JFrame {

    GameFrame(){
        this.setSize(GameConstants.GWIDTH, GameConstants.GHEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("Game -2024");
        setLocationRelativeTo(null);
        add(new Board());
        setVisible(true);
    }

    public static void main(String[] args) {
        GameFrame frame = new GameFrame();
       
    }
}