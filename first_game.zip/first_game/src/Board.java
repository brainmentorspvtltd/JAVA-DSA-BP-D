import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;


// this is the canvas of a game
// all things will be draw here e.g Player, Enemy, Background
public class Board extends JPanel implements GameConstants{
    BufferedImage background;
    public Board(){
        loadBackground();
    }
    private void loadBackground(){
        try{
        background = ImageIO.read(Board.class.getResource("bg1.jpg"));
        }
        catch(Exception e){
            System.out.println("Unable to load Background Image");
            System.out.println(e);
        }
    }
   // @Deprecated
    @Override
    public void paintComponent(Graphics pen){
        super.paintComponent(pen);
        pen.drawImage(background,0,0,GWIDTH, GHEIGHT,null);
    }
}
