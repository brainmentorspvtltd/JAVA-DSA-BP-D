public interface GameConstants {
    int GWIDTH = 1200; // public static final int WIDTH = 900
    int GHEIGHT = 900;
}
