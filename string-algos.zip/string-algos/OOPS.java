// Class - BluePrint / Template / Plan / Structure
// PascalCase
// Noun
// public , default
// public - access within the package , and outside the package
// Encapsulation - Member Variable + Methods
// e.g class
// Good Encapsulation - private data members + public methods

class Employee{

    // Members
    // Instance variables 
    private int id; // camelCase
    private String name;
    private double salary;
    private String companyName;
    private double bonus;
    private double shares;
    private String email;
    private String phone;

    private class H{
        void show(){
            class E{

            }
        }
    }


    static{
        //System.out.println("run when class is load");
    }
    {
        // System.out.println("Init Block.....");
        // System.out.println(id);
        // System.out.println(name);
        // System.out.println(salary);
    }
    {
        //System.out.println("Init Block 2");
    }
    // Constructor - Instance Variables Initalize
    private Employee(){
       // this(10, "ABcd", 9999);
        companyName = "SkillRisers";
        // id = 1;
        // name ="No Name";

        // this.id = 0;
        // this.name = "";
        // this.salary = 0.0;
        System.out.println("I am a default ");
    }
    public Employee(int id, String name, double salary, double bonus, double shares){
        this(id, name, salary);
        this.bonus = bonus;
        this.shares = shares;
    }     
    public Employee(int id, String name, double salary){
       //Employee();
         this(); 
        // Shadow Problem
        // this - keyword 
        // this - current calling object reference
        // Instance Var = Local var
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    public void print(){
        System.out.println("id "+this.id);
        System.out.println("Name "+name);
        System.out.println("Salary "+salary);
        System.out.println("Company "+companyName);
    }
}
class Node{
    int data;
    Node next;
}
// Lambda 
// DRY 
public class OOPS {
    public static void main(String[] args) {
        int m = 0;
       // System.out.println(m);
        //System.out.println("Hello OOPS");
        Employee emp = new Employee(1001, "Ram", 99999);
        // emp.id = 0;
        // emp.salary = -99999;

        emp.print();
        //Employee emp = new Employee();
        // System.out.println(emp.id);
        // System.out.println(emp.name);
        // System.out.println(emp.salary);
    }
}
