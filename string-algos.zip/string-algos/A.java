class A{
    public static void main(String[] args) {
        String a = "Amit";
        //a[0]
        a.substring(2, 5);
    }
}