class B{
    private B(){

    }
    
}
public class T {
    public static void main(String[] args) {
       // B obj = new B();
      //  System s = new System();
        System.out.println();
    }
}
