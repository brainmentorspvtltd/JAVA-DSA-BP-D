/*
 * Saving Account
 * Current Account
 */
class Account {
    int id;
    String name;

    void deposit() {
        System.out.println("Account Deposit...");
    }

    void withDraw() {
        System.out.println("Account WithDraw...");
    }

    void roi() {
        System.out.println("Account ROI...");
    }
}

class SavingAccount extends Account {
    void limit() {
        System.out.println("Saving Account Daily Limit of 50 Lakh");
    }
}

class CurrentAccount extends Account {
    void odLimit() {
        System.out.println("Current Account No Limit Extra WithDraw");
    }
}

public class ISA {
    public static void main(String[] args) {
        SavingAccount sa = new SavingAccount();
        sa.deposit();
        sa.withDraw();
        sa.roi();
        sa.limit();
        System.out.println("*****************************");
        CurrentAccount ca = new CurrentAccount();
        ca.deposit();
        ca.withDraw();
        ca.roi();
        ca.odLimit();
    }
}