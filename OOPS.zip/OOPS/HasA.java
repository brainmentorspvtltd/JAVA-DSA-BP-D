public class HasA {

}
